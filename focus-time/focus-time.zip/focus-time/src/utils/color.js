export const colors = {
  white : '#fff',
  darkBLue : '#253350',
  progressBar: '#5e84e2',
}